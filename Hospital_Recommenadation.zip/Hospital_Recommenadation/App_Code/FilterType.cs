﻿/// <summary>
/// Summary description for FilterType
/// </summary>
public enum FilterType
{
    ByCost = 1,
    ByTreatment = 2,
    ByFacility = 3,
    ByRating = 4,
    ByDoctor = 5,
    ByLocation = 6
}